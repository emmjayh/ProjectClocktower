Blood on the Clocktower AI Agent - Windows Version

[GAME] FIRST TIME SETUP:
1. Run "download_models.bat" FIRST to download AI models
   (This downloads speech recognition and text-to-speech models)
   
2. After models download, run "BloodClockTowerAI.exe"

[GAME] HOW TO USE:
- Enter player names in the Setup tab (one per line)
- Choose your script (Trouble Brewing recommended for beginners)
- Select storyteller voice
- Click "Start New Game"
- Use the Game Control tab to manage phases
- The AI will guide you through the game!

[CONFIG] TROUBLESHOOTING:
- If audio doesn't work, check Windows sound settings
- Make sure microphone permissions are enabled
- For best results, use a quiet room
- If speech recognition fails, use manual text input

[NOTE] CONTROLS:
- Speech recognition listens automatically during game
- Use manual text input if voice commands don't work
- Game log shows all actions and events
- Players tab shows current game state

[TARGET] REQUIREMENTS:
- Windows 10/11
- Microphone for voice commands
- Speakers/headphones for AI narration
- Internet connection for initial model download

For support, visit: https://github.com/your-repo/issues
